let notAtomConfigTypes = ['array', 'object', 'group', 'colors', 'menu', 'modal'];
export function reduceConfig(config) {
  if (!Array.isArray(config)) {
    return config;
  }
  return config.reduce((result, item) => {
    result[item.name] = item.type && !notAtomConfigTypes.includes(item.type) ? item.value : reduceConfig(item.value);
    return result;
  }, {});
}