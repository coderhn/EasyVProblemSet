import React, { useRef } from 'react';
import { Map, Marker, MapApiLoaderHOC } from 'react-bmapgl';

const MyComponent = props => {
  const { width, height, left, top, id } = props;
  let mapRef = useRef(null)

  const styles = {
    position: 'absolute',
    left, top,
    width, height,
  };


  return (
    <div className="__easyv-component" style={styles} id={id}>
      <Map
        className='map'
        style={{ position: 'absolute', width, height, zIndex: 0 }}
        center={new BMapGL.Point(116.404449, 39.914889)}
        zoom={12}
        tilt={40}
        ref={mapRef}
      >
        <Marker
          className='marker'
          position={new BMapGL.Point(116.404449, 39.914889)}
          enableDragging
          onClick={(e) => {
            var opts = {
              width: 200,     // 信息窗口宽度
              height: 100,     // 信息窗口高度
              title: "故宫博物院", // 信息窗口标题
              message: "这里是故宫"
            }
            var infoWindow = new BMapGL.InfoWindow("地址：北京市东城区王府井大街88号乐天银泰百货八层", opts);  // 创建信息窗口对象 Q
            mapRef.current.map.openInfoWindow(infoWindow, new BMapGL.Point(116.404449, 39.914889));
            console.log('mapRef', mapRef.current.map);
          }}
        />
      </Map>
    </div>
  );
};

export default MapApiLoaderHOC({ ak: '百度地图的key', style: {} })(MyComponent);
