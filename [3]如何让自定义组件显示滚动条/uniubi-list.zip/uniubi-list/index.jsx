import React, { useState, useEffect } from 'react';
import { reduceConfig } from './utils/reduce-config';
import css from './styles/index.module.css';
import classnames from 'classnames'


export default function (props) {
  const { left, top, width, height, id, onRelative, data, configuration } = props;
  const [deviceKey, setDeviceKey] = useState()
  const config = reduceConfig(configuration);
  const {
    headerStyle,
  } = config;

  useEffect(() => {
    let key = deviceKey
    if (!data.map(item => item.deviceKey).includes(key)) key = data && data[0] && data[0].deviceKey || ''
    onCallbackData(key)
  }, [data])

  // 自定义逻辑
  const styles = {
    position: 'absolute',
    left, top, width, height,
    textAlign: 'center'
  };

  const onCallbackData = (key) => {
    if (!key) return
    setDeviceKey(key)
    const callbacks = Object.values(config.interaction.callback); // 1
    if (callbacks.length) {
      const callbackData = {};
      callbacks
        .map((o) => {
          const item = data.find(item => item.deviceKey === key); // data为组件数据对象
          if (o.origin in item) { // 2
            callbackData[o.target] = item[o.origin];  // 3
          }
        });
      onRelative(id, callbackData)  // 4
    }
  }

  /**
   * 固定格式: 返回的div必须有className/id属性
   */
  return (
    <div className="__easyv-component" id={id}>
      <div className={css.header}>
        <div>设备名称</div>
        <div>在线状态</div>
        <div>报警状态</div>
      </div>
      <div className={css.scroll} style={{ overflowY: 'auto', height: height - 28}}>
        {
          data.map(item => (
            <> <div className={classnames(css.centerItem, deviceKey === item.deviceKey ? css.active : '')} onClick={() => onCallbackData(item.deviceKey)}>
              <div>{item.deviceName}</div>
              <div><span className={item.onlineStatus === '在线' ? css.green : css.yellow}>{item.onlineStatus}</span></div>
              <div>{item.alarmStatus}</div>
            </div></>
          ))
        }
      </div>
    </div>
  );
}